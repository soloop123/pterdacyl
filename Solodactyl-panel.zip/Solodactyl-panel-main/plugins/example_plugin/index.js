const express = require('express');
const router = require('./router');

function register(addonManager) {
    //console.log('loaded!');
}

module.exports = {
    register,
    router
};
