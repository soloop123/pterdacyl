const { db } = require('../handlers/db.js');
const config = require('../config.json');
const { v4: uuidv4 } = require('uuid');
const log = new (require('cat-loggr'))();

async function init() {
    const Solodactyl = await db.get('Solodactyl_instance');
    if (!Solodactyl) {
        log.init('This is probably your first time starting Solodactyl, welcome!');
        log.init('You can find documentation for the panel at Solodactyl.dev');

        const errorMessages = [];

        let imageCheck = await db.get('images');
        let userCheck = await db.get('users');

        if (!imageCheck) {
            errorMessages.push("Before starting Solodactyl for the first time, you didn't run the seed command!");
            errorMessages.push("Please run: npm run seed");
        }
        
        if (!userCheck) {
            errorMessages.push("If you didn't do it already, make a user for yourself: npm run createUser");
        }

        if (errorMessages.length > 0) {
            errorMessages.forEach(errorMsg => log.error(errorMsg));
            process.exit(); 
        }


        const SolodactylId = uuidv4();
        const setupTime = Date.now();
        
        const info = {
            SolodactylId: SolodactylId,
            setupTime: setupTime,
            originalVersion: config.version
        };

        await db.set('Solodactyl_instance', info);
        log.info('Initialized Solodactyl panel with ID: ' + SolodactylId);
    }
    log.info('Init complete!');
}

module.exports = { init };